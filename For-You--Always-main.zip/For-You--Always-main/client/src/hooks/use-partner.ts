import { partnerConfig } from "@/config/partner.config";

export function usePartner() {
  return partnerConfig;
}
